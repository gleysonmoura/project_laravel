

<?php $carbon = app('Carbon\Carbon'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbars.auth.topnav', ['title' => 'Anotações'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-4">
    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <?php $__currentLoopData = $anotacao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anotacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-header p-3 pb-0">
                    <h6 class="mb-1">
                        <?php echo e($anotacao->assunto_nome); ?>

                    </h6>
                    <p class="text-sm mb-0">
                        <?php echo e($anotacao->titulo_anotacao); ?>

                    </p>
                </div>
                <div class="card-body p-3">
                    <ul class="text-muted ps-4 mb-0">
                        <li>
                            <span class="text-sm"><?php echo e($anotacao->texto_anotacao); ?></span>
                        </li>

                    </ul>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\mystudy-prod\resources\views/pages/anotacao/anotacao-show.blade.php ENDPATH**/ ?>