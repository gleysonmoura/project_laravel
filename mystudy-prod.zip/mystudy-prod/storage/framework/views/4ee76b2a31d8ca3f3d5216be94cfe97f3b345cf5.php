<div class="modal fade" id="Modaldesempenho" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-default" id="exampleModalLabel">Meta questões</h5>
                <button type="button" class="btn-close btn-sm" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <form method="POST" action="<?php echo e(route('desempenho.finalizarexercicio', $exercicio->id)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <p class="text-sm font-weight-bold text-secondary mb-0"> Meta de Questões
                                
                                <?php echo e($exercicio->id); ?>

                            </p>

                            <span class="mb-0 font-weight-bold text-sm">
                                <h6 class="text-danger"></h6>
                            </span>
                            <input style="display:none;" type="text" value="<?php echo e($exercicio->id); ?>" name="id_meta"
                                class="form-control form-control-sm">
                        </div>
                        

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-sm bg-gradient-primary">Save</button>
            </div>
            </form>
        </div>
    </div>
</div>
<script>
    $('tbody').delegate('.quantidade_questoes, .questoes_certas', 'keyup', function() {
    var tr = $(this).parent().parent();
    var qq = tr.find('.quantidade_questoes').val();
    var qc = tr.find('.questoes_certas').val();
    var qe = (qq - qc);
    var de = ((qc / qq) * 100.00);
    /* var sinal = "%"; */
    tr.find('.desempenho').val(de + " " /* + sinal */);
    tr.find('.questoes_erradas').val(qe);
    });
</script><?php /**PATH C:\xampp\htdocs\project_laravel\mystudy-prod\resources\views/pages/desempenhos/modal-desempenho.blade.php ENDPATH**/ ?>