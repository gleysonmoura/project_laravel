
<?php $carbon = app('Carbon\Carbon'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbars.auth.topnav-home', ['title' => 'Plano de Estudo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbars.auth.sidenav-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid py-4">
    
    <div class="row mt-2 mx-4 col-12">
        <?php echo $__env->make('alert-notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row mt-4 ">
        <div class="col-lg-12 col-12">
            <div class="card">
                <div class="card-header pb-0">
                    <div class="d-lg-flex">
                        <h6 class="mb-0">Planos de Estudos</h6>
                        <div class="ms-auto my-auto mt-lg-0 mt-4">
                            <div class="ms-auto my-auto">
                                <a href="<?php echo e(route('planoestudo.create')); ?>"
                                    class="btn bg-gradient-primary btn-sm mb-0">+&nbsp;
                                    Add
                                    Plano</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body px-0 pb-0">
                    
            </div>
        </div>
    </div>
    <?php $__empty_1 = true; $__currentLoopData = $planos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-12 col-lg-6">
        <div class="card mt-4">
            <div class="card-body p-3">
                <div class="d-flex">
                    <div class="avatar avatar-lg">
                        <i class="fa-solid fa-person-chalkboard fa-xl"></i>
                    </div>
                    <div class="ms-3 my-auto">
                        <h6 class="mb-0"><?php echo e(strtoupper($item->plano_nome)); ?></h6>
                        <p class="text-xs mb-0"><?php echo e($carbon::parse($item->plano_data)->format('d/m/Y')); ?></p>

                    </div>
                    <div class="ms-auto">
                        <div class="dropdown">
                            <button class="btn btn-link text-secondary ps-0 pe-2" title="Ações"
                                id="navbarDropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                                <i class="fa fa-ellipsis-v text-lg" aria-hidden="true"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end me-sm-n4 me-n3"
                                aria-labelledby="navbarDropdownMenuLink" style="">
                                <a class="dropdown-item" href="javascript:;">Editar</a>
                                <form action="<?php echo e(route('planoestudo.destroy', $item->id)); ?>" class="delete_form"
                                    method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button class=" dropdown-item">
                                        Excluir
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <p class="mt-3"> You have an upcoming meet for Marketing Planning</p>
                <span class="badge badge-sm bg-gradient-warning "><?php echo e($item->plano_status); ?></span>
                <hr class="horizontal light">
                <div class="d-flex">
                    <a href="<?php echo e(route('planoestudo.show', $item->id)); ?>"
                        class="btn bg-gradient-primary btn-sm float-end mt-2 mb-0">
                        Estudar
                    </a>

                </div>
            </div>
        </div>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class=" bg-gradient-default">
        <div class="card-body">
            <h5 class="card-title text-info text-warning">Olá,
                <?php echo e(ucwords(auth()->user()->firstname)); ?>

                <?php echo e(ucwords(auth()->user()->lastname)); ?>

            </h5>
            <blockquote class="blockquote text-white mb-0">
                <p class="text-dark ms-3">Você ainda não tem um plano de estudo!</p>
                <footer class="blockquote-footer text-secondary text-sm ms-3">
                    Faça o cadastro e comece seus estudos.
                </footer>
            </blockquote>
        </div>
    </div>
    <?php endif; ?>
    <?php $__currentLoopData = $planos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





</div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\mystudy-prod\resources\views/pages/planoestudo/planoestudo-index.blade.php ENDPATH**/ ?>