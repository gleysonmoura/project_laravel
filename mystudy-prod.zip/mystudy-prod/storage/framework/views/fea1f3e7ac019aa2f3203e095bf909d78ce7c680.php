

<?php $carbon = app('Carbon\Carbon'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbars.auth.topnav', ['title' => 'Anotações'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12 mx-auto">
            <div class="card card-body mt-4">
                <div class="card-header d-flex justify-content-between">
                    <h6 class="mb-0">Anotações</h6>
                    <?php $__currentLoopData = $atividadeshow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="text-sm mb-0">Assunto - <?php echo e($item->assunto_nome); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <hr class="horizontal my-3 light">
                <form method="POST" action="<?php echo e(route('anotacao.storeanotacao', $item->id)); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col-12">
                            <div class="rating-wrapper" data-id="raiders">
                                <label class="mt-4">Nível de importância</label>
                                <div class="star-wrapper">
                                    <i class="fa-regular fa-star" value='1'></i>
                                    <i class="fa-regular fa-star"></i>
                                    <i class="fa-regular fa-star"></i>
                                    <i class="fa-regular fa-star"></i>
                                    <i class="fa-regular fa-star"></i>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-12">
                            <label class="mt-4">Titulo da anotação</label>
                            <input type="text" class="form-control value=" <?php echo e(old('titulo_anotacao')); ?>"
                                id="titulo_anotacao" name="titulo_anotacao">
                            <?php $__errorArgs = ['titulo_anotacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger text-xs pt-1"> <?php echo e($message); ?> </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <label class="mt-4">Observação</label>
                            <div class="form-group">
                                <textarea class="form-control" id="descricao_anotacao" name="descricao_anotacao"
                                    rows="3"></textarea>
                                <?php $__errorArgs = ['descricao_anotacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger text-xs pt-1"> <?php echo e($message); ?> </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                    </div>
                    <div class="d-flex justify-content-end mt-4">
                        <button type="button" name="button" class="btn btn-sm btn-light m-0">Cancel</button>
                        <button type="submit" name="button" class="btn btn-sm bg-gradient-primary m-0 ms-2">Criar
                            Anotação</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
</div>


<script>
    $("div.star-wrapper i").on("mouseover", function () {
if ($(this).siblings("i.vote-recorded").length == 0) {
$(this).prevAll().addBack().addClass("fa-solid yellow").removeClass("fa-regular");
$(this).nextAll().removeClass("fa-solid yellow").addClass("fa-regular");
}
});

   
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\mystudy-prod\resources\views/pages/anotacao/storeanotacao.blade.php ENDPATH**/ ?>