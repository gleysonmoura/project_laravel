<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbars.auth.topnav', ['title' => 'Profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-4">
    <div class="row">
        <ul class="list-group">
            <li class="list-group-item"><b>Alterar index da page atividade.</b>
                <br /> - mostrar as atividades em tabela
                <br> - incluir opção de delete e edtitar
            </li>
            <li class="list-group-item">pegar o codigo timeline e incluir na index dashboard</li>
            <li class="list-group-item"><b>Tag Revisão</b>
                <br /> - criar crud para revisão
            </li>
            <li class="list-group-item">Porta ac consectetur ac</li>
            <li class="list-group-item">Vestibulum at eros</li>
        </ul>
    </div>
    <?php echo $__env->make('layouts.footers.auth.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\mystudy-prod\resources\views/pages/profile-static.blade.php ENDPATH**/ ?>