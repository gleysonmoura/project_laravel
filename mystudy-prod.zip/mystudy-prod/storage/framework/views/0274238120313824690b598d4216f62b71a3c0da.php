

<?php $carbon = app('Carbon\Carbon'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbars.auth.topnav', ['title' => 'Atividades'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-center col-lg-12 mt-4">
        <?php echo $__env->make('alert-notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="d-flex justify-content-center mb-5">

        <div class="col-lg-9 mt-lg-0 mt-4">
            <div class="card mt-4">
                <?php $__currentLoopData = $atividadeshow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-header d-flex align-items-center">
                    <div class="d-flex align-items-center">
                        <div class="">
                            <h5 class="text-white font-weight-700 mt-lg-0 mt-4"><?php echo e(Str::ucfirst($item->assunto_nome)); ?>

                            </h5>
                            <small
                                class="d-block mb-0 text-white font-weight-bold text-sm"><?php echo e(ucwords($item->disciplina_none)); ?>

                            </small>

                            <div class="rating mt-4">
                                <span class="mb-0 text-white font-weight-bold text-sm">Incidência de Prova</span>
                                <?php if($item->atividade_prioridade == 'baixa'): ?>
                                <i class="fas fa-star text-primary" aria-hidden="true"></i>
                                <?php else: ?>
                                <?php if($item->atividade_prioridade == 'média'): ?>
                                <i class="fas fa-star text-success" aria-hidden="true"></i>
                                <i class="fas fa-star text-success" aria-hidden="true"></i>
                                <?php else: ?>
                                <?php if($item->atividade_prioridade == 'alta'): ?>
                                <i class="fas fa-star text-warning" aria-hidden="true"></i>
                                <i class="fas fa-star text-warning" aria-hidden="true"></i>
                                <i class="fas fa-star text-warning" aria-hidden="true"></i>
                                <?php else: ?>
                                <i class="fas fa-star text-danger" aria-hidden="true"></i>
                                <i class="fas fa-star text-danger" aria-hidden="true"></i>
                                <i class="fas fa-star text-danger" aria-hidden="true"></i>
                                <i class="fas fa-star text-danger" aria-hidden="true"></i>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>

                    <div class="text-end ms-auto">
                        <div class="dropdown">
                            <button class="btn bg-gradient-info btn-sm dropdown-toggle" type="button"
                                id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                Ações
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <li><a class="dropdown-item text-white" data-bs-toggle="modal"
                                        data-bs-target="#Modaladdexercicio" href="#">Add Meta Exercicios</a></li>
                                <li><a class="dropdown-item text-white"
                                        href="<?php echo e(route('anotacao.addnotas', $item->id )); ?>">Add
                                        anotações</a></li>
                                <li><a class="dropdown-item text-white"
                                        href="<?php echo e(route('atividade.finalizaratividade', $item->id)); ?>">Finalizar
                                        Atividade</a></li>
                            </ul>
                        </div>
                        
                    </div>
                </div>
                <hr class="horizontal my-3 light">
                <div class="card-body p-3">
                    <label class="mb-0 font-weight-bold text-sm">Observação</label>
                    
                    <p>
                        <?php $__currentLoopData = explode(';', $item->atividade_observacao); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul>
                        <li class="text-white">
                            <?php echo e(ucwords($info)); ?>

                        </li>
                    </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                    <hr class="horizontal gray-light my-2">
                    <div class="">
                        <label class="mb-0 font-weight-bold text-sm">Você tem que</label> <br>
                        <?php $__currentLoopData = explode(',', $item->atividade_tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge bg-gradient-success text-white badge-sm"><?php echo e($info); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <hr class="horizontal gray-light my-2">
                    <div class="">
                        <label class="mb-0 font-weight-bold text-sm">Data de início e termino</label> <br>
                        <span
                            class="badge badge-pill bg-gradient-secondary badge-sm"><?php echo e($carbon::parse($item->atividade_data)->format('d/m/Y')); ?></span>
                        <span
                            class="badge badge-pill bg-gradient-secondary badge-sm"><?php echo e($carbon::parse($item->atividade_tempo)->format('d/m/Y')); ?></span>
                    </div>
                    <hr class="horizontal gray-light my-2">
                    <div class="mt-1">
                        <?php $__empty_1 = true; $__currentLoopData = $exercicio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label class="mb-0 font-weight-bold text-sm">Você tem exercício para fazer</label> <br>
                        <span class="badge badge-warning"><?php echo e($exer->exer_quantidade); ?></span>
                        questões sobre o assunto <?php echo e(Str::ucfirst($item->assunto_nome)); ?> -
                        <span class="badge c bg-gradient-danger mt-4"><?php echo e($exer->exer_status); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </div>
                    <hr class="horizontal gray-white my-2">
                    <a type="submit" href="<?php echo e(URL::previous()); ?>"
                        class="btn bg-gradient-primary btn-sm float-end mt-6 mb-0">Voltar</a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-12 col-lg-12 mt-4">
                <div class="col-12 col-md-12 mb-4 mb-md-0">
                    <div class="card bg-gradient-dark">
                        <div class="card-body">
                            <div class="mb-2">
                                <sup class="text-white">%</sup> <span
                                    class="h2 text-white"><?php echo e(number_format($count_porcentagem,2,",",".")); ?></span>
                                <div class="text-white opacity-8 mt-2 text-sm">Desempenho do Assunto</div>
                                <div>
                                    <span class="text-success font-weight-600"><?php echo e($count_quantidade_total); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer pt-0">
                            <div class="row">
                                <div class="col">
                                    <small class="text-white opacity-8">Certas: <?php echo e($count_quantidade_certas); ?></small>
                                    <div class="progress progress-xs my-2">
                                        <div class="progress-bar bg-success" aria-valuemin="0"
                                            aria-valuemax="<?php echo e($count_quantidade_total); ?>"
                                            style="width: <?php echo e($count_quantidade_certas); ?>%">
                                        </div>
                                    </div>
                                </div>
                                <div class="col"><small class="text-white opacity-8">Erradas:
                                        <?php echo e($count_quantidade_erradas); ?></small>
                                    <div class="progress progress-xs my-2">
                                        <div class="progress-bar bg-warning"
                                            style="width: <?php echo e($count_quantidade_erradas); ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('pages.exercicio.create-exercicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\mystudy-prod\resources\views/pages/atividades/atividade-show.blade.php ENDPATH**/ ?>