
<?php $carbon = app('Carbon\Carbon'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbars.auth.topnav', ['title' => 'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-xl-12 col-sm-6 mb-xl-0 mb-4">
            <div class="card card-body">
                <div class="col-sm-auto col-4">
                    <div class="h-100">
                        <h6 class="mb-1 font-weight-bolder">
                            <?php echo e($planos->plano_nome); ?> - <?php echo e($carbon::parse($planos->plano_data)->format('Y')); ?>

                        </h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-lg-12 col-12">
            <div class="card">
                <div class="card-header pb-0">
                    <h6>Resumo do meu desempenho geral</h6>
                </div>
                <div class="card-body p-3">
                    <div class="row">
                        <div class="col-lg-3 col-6 text-center">
                            <div class="border-dashed border-1 border-secondary border-radius-md py-3">
                                <h6 class="text-primary mb-0">Total Atividades</h6>
                                <h4 class="font-weight-bolder"><span id="state1"
                                        countto="23980"><?php echo e($count_atividade); ?></span></h4>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6 text-center">
                            <div class="border-dashed border-1 border-secondary border-radius-md py-3">
                                <h6 class="text-primary mb-0">Exercícios Resolvidos</h6>
                                <h4 class="font-weight-bolder"><span id="state1" countto="23980"><?php echo e($count); ?></span>
                                </h4>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6 text-center">
                            <div class="border-dashed border-1 border-secondary border-radius-md py-3">
                                <h6 class="text-primary mb-0">Assuntos Estudados</h6>
                                <h4 class="font-weight-bolder"><span id="state1" countto="23980"><?php echo e($count); ?></span>
                                </h4>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6 text-center">
                            <div class="border-dashed border-1 border-secondary border-radius-md py-3">
                                <h6 class="text-primary mb-0">Produtividade</h6>
                                <h4 class="font-weight-bolder"><span id="state1" countto="23980"><?php echo e($count); ?></span>
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-12 col-lg-7">
            <div class="card mb-3 mt-lg-0 mt-4">
                <div class="card-header pb-0">
                    <h6>Conteúdo</h6>
                </div>
                <div class="card-body p-3">
                    <div class="accordion-1">
                        <div class="container">
                            <div class="row">
                                <div class="col-12 mx-auto">
                                    <?php $__currentLoopData = $disciplinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $disciplina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="accordion" id="accordionRental">
                                        <div class="accordion-item mb-3">
                                            <h5 class="accordion-header" id="headingOne">
                                                <button
                                                    class="accordion-button border-bottom font-weight-bold collapsed"
                                                    type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#collapseOne<?php echo e($key); ?>" aria-expanded="false"
                                                    aria-controls="collapseOne<?php echo e($key); ?>">
                                                    <h6><?php echo e($disciplina->disciplina_none); ?></h6>

                                                    <i class="collapse-close fa fa-plus text-xs pt-1 position-absolute end-0 me-3"
                                                        aria-hidden="true"></i>
                                                    <i class="collapse-open fa fa-minus text-xs pt-1 position-absolute end-0 me-3"
                                                        aria-hidden="true"></i>
                                                </button>
                                            </h5>
                                            <div id="collapseOne<?php echo e($key); ?>" class="accordion-collapse collapse"
                                                aria-labelledby="headingOne<?php echo e($key); ?>" data-bs-parent="#accordionRental"
                                                style="">
                                                <div class="accordion-body text-sm opacity-8">

                                                    <div class="">
                                                        <?php $__currentLoopData = $disciplina->assuntos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assunto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="d-flex justify-content-between">
                                                            <span class="mb-2 text-sm">
                                                                <i class="fa-solid fa-angles-right aria-hidden="
                                                                    true""></i> <?php echo e($assunto->assunto_nome); ?>

                                                            </span>
                                                            <span class="text-dark font-weight-bold ms-2"><a
                                                                    href="<?php echo e(route('viewestudar.show', $assunto->id)); ?>"
                                                                    class="text-primary text-sm icon-move-right my-auto text-end">estudar
                                                                    <i class="fas fa-arrow-right text-xs ms-1"
                                                                        aria-hidden="true"></i>
                                                                </a></span>
                                                        </div>
                                                        <hr class="horizontal light" style="margin:1%">
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-5">
            <div class="card mb-3 mt-lg-0 mt-4">
                <div class="card-header pb-0">
                    <h6>Timeline de Atividades</h6>
                </div>
                <div class="card-body p-3">

                    <div class="timeline timeline-one-side" data-timeline-axis-style="dotted">
                        <?php $__currentLoopData = $atividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="timeline-block mb-3">

                            <?php if($item->atividade_data > date("Y-m-d")): ?>
                            <span class="timeline-step">
                                <i class="ni ni-bell-55 text-info text-gradient"></i>
                            </span>
                            <?php else: ?>
                            <?php if($item->atividade_data == date("Y-m-d")): ?>
                            <span class="timeline-step">
                                <i class="ni ni-bell-55 text-warning text-gradient"></i>
                            </span>
                            <?php else: ?>
                            <span class="timeline-step">
                                <i class="ni ni-bell-55 text-danger text-gradient"></i>
                            </span>
                            <?php endif; ?>
                            <?php endif; ?>
                            <div class="timeline-content">
                                <h6 class="text-dark  font-weight-bold mb-0">
                                    <?php echo e(ucwords($item->disciplina_none)); ?> -
                                    <?php echo e(Str::ucfirst($item->assunto_nome)); ?>

                                </h6>
                                <p class="text-secondary font-weight-bold text-xs mt-1 mb-0">
                                    de <?php echo e($carbon::parse($item->atividade_data)->format('d/m/Y')); ?> até
                                    <?php echo e($carbon::parse($item->atividade_tempo)->format('d/m/Y')); ?>

                                </p>
                                <p class="text-sm mt-3 mb-2">
                                    <?php echo e($item->atividade_observacao); ?>

                                </p>
                                <?php if($item->atividade_prioridade == 'altissima'): ?>
                                <span class="badge badge-sm bg-gradient-danger"><?php echo e($item->atividade_prioridade); ?></span>
                                <?php else: ?>
                                <?php if($item->atividade_prioridade == 'alta'): ?>
                                <span
                                    class="badge badge-sm bg-gradient-warning"><?php echo e($item->atividade_prioridade); ?></span>
                                <?php else: ?>
                                <?php if($item->atividade_prioridade == 'media'): ?>
                                <span
                                    class="badge badge-sm bg-gradient-primary"><?php echo e($item->atividade_prioridade); ?></span>
                                <?php else: ?>
                                <span
                                    class="badge badge-sm bg-gradient-secondary"><?php echo e($item->atividade_prioridade); ?></span>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php endif; ?>

                                <?php $__currentLoopData = explode(',', $item->atividade_tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                - <span class="badge bg-gradient-info badge-sm"><?php echo e($info); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <a class="text-sm text-secondary d-flex justify-content-end font-weight-bold mb-0 icon-move-right mt-2"
                                    href="<?php echo e(route('atividade.showAtividade', $item->id)); ?>">

                                    <i class="fas fa-eye text-secondary  ms-1" title="Ver atividade"
                                        aria-hidden="true"></i>
                                </a>
                            </div>

                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
            <div class="card mb-3 mt-lg-0 mt-4">
                <div class="card-header">
                    <h5 class="mb-0 text-capitalize">To do list</h5>
                    <small class="text-xs"><?php echo e(date('d/m/Y')); ?></small>
                </div>
                <div class="card-body pt-0">
                    <ul class="list-group list-group-flush" data-toggle="checklist">
                        <li class="checklist-entry list-group-item px-0">
                            <div class="checklist-item checklist-item-success checklist-item-checked d-flex">
                                <div class="checklist-info">
                                    <h6 class="checklist-title mb-0">Meta do dia</h6>

                                </div>
                                <div class="form-check my-auto ms-auto">
                                    <?php echo e($count_exe); ?>

                                </div>
                            </div>
                        </li>
                        <li class="checklist-entry list-group-item px-0">
                            <div class="checklist-item checklist-item-warning d-flex">
                                <div class="checklist-info">
                                    <h6 class="checklist-title mb-0">Atividades do dia</h6>
                                </div>
                                <div class="form-check my-auto ms-auto">
                                    <?php echo e($count_atividades); ?>

                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-7 col-md-6 mb-4 mb-lg-0">

        </div>
        <div class="col-lg-5 col-md-6 mb-4 mb-lg-0">

        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="./assets/js/plugins/chartjs.min.js"></script>
<script>
    var ctx1 = document.getElementById("chart-line").getContext("2d");

        var gradientStroke1 = ctx1.createLinearGradient(0, 230, 0, 50);

        gradientStroke1.addColorStop(1, 'rgba(251, 99, 64, 0.2)');
        gradientStroke1.addColorStop(0.2, 'rgba(251, 99, 64, 0.0)');
        gradientStroke1.addColorStop(0, 'rgba(251, 99, 64, 0)');
        new Chart(ctx1, {
            type: "line",
            data: {
                labels: ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                datasets: [{
                    label: "Mobile apps",
                    tension: 0.4,
                    borderWidth: 0,
                    pointRadius: 0,
                    borderColor: "#fb6340",
                    backgroundColor: gradientStroke1,
                    borderWidth: 3,
                    fill: true,
                    data: [50, 40, 300, 220, 500, 250, 400, 230, 500],
                    maxBarThickness: 6

                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false,
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index',
                },
                scales: {
                    y: {
                        grid: {
                            drawBorder: false,
                            display: true,
                            drawOnChartArea: true,
                            drawTicks: false,
                            borderDash: [5, 5]
                        },
                        ticks: {
                            display: true,
                            padding: 10,
                            color: '#fbfbfb',
                            font: {
                                size: 11,
                                family: "Open Sans",
                                style: 'normal',
                                lineHeight: 2
                            },
                        }
                    },
                    x: {
                        grid: {
                            drawBorder: false,
                            display: false,
                            drawOnChartArea: false,
                            drawTicks: false,
                            borderDash: [5, 5]
                        },
                        ticks: {
                            display: true,
                            color: '#ccc',
                            padding: 20,
                            font: {
                                size: 11,
                                family: "Open Sans",
                                style: 'normal',
                                lineHeight: 2
                            },
                        }
                    },
                },
            },
        });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\mystudy-prod\resources\views/pages/planoestudo/planoestudo-show.blade.php ENDPATH**/ ?>