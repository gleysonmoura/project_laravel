
<?php $carbon = app('Carbon\Carbon'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbars.auth.topnav', ['title' => 'Desempenho'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-4">
    <div class="row mt-4">
        <div class="col-12 col-md-8 mb-4 mb-md-0">
            <div class="card">
                <div class="card-header pb-0">
                    <div class="d-lg-flex">
                        <h6 class="mb-0">Estatísticas de Assuntos</h6>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-items-center mb-0">
                        <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Assunto</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                    Certas</th>
                                <th
                                    class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Erradas</th>
                                <th
                                    class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    %</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $desempenhos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desempenho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="d-flex px-2 py-1">
                                        <?php echo e($desempenho->assunto_nome); ?>

                                    </div>
                                </td>
                                <td>
                                    <?php echo e($desempenho->desempenho_certas); ?>

                                </td>
                                <td class="align-middle text-center text-sm">
                                    <?php echo e($desempenho->desempenho_erradas); ?>

                                </td>
                                <td class="align-middle text-center">
                                    <span
                                        class="text-secondary text-xs font-weight-bold"><?php echo e($desempenho->desempenho_porcentagem); ?></span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header pb-0 p-3">
                    <h6 class="mb-0">Assuntos Baixo Aproveitamento</h6>
                </div>
                <div class="card-body p-3">
                    <ul class="list-group">
                        <?php $__currentLoopData = $dados_atividade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="ni ni-mobile-button text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm"><?php echo e($item->assunto_nome); ?></h6>
                                    <span class="text-xs">último estudo<span class="font-weight-bold">
                                            <?php echo e($item->updated_at); ?></span></span>
                                </div>
                            </div>
                            <div class="d-flex">
                                <button
                                    class="btn btn-link btn-icon-only btn-rounded btn-sm text-dark icon-move-right my-auto"><i
                                        class="ni ni-bold-right" aria-hidden="true"></i></button>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\mystudy-prod\resources\views/pages/desempenhos/index-desempenho.blade.php ENDPATH**/ ?>