
<?php $__env->startSection('content'); ?>
<?php $carbon = app('Carbon\Carbon'); ?>
<?php echo $__env->make('layouts.navbars.auth.topnav-home', ['title' => 'Plano de Estudo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbars.auth.sidenav-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid py-4">
    <div class="row mt-4">
        <div class="col-12">
            <div class="card card-body mt-4">
                <div class="card-header d-flex justify-content-between">
                    <h6 class="mb-0">Plano de Estudos</h6>
                </div>
                <form method="POST" action="<?php echo e(route('planoestudo.store')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col-12">
                            <label class="form-label">Nome do plano</label>
                            <div class="form-group">
                                <div class="form-group">
                                    <input type="text" name="nome_plano" class="form-control value=" <?php echo e(old('nome_plano')); ?>" id=" nome_plano">
                                    <?php $__errorArgs = ['nome_plano'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger text-xs pt-1"> <?php echo e($message); ?> </p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <label class="form-label">Data da Prova</label>
                            <div class="form-group">
                                <input class="form-control value=" <?php echo e(old('data_plano')); ?>" type="date" id="data_plano"
                                    name="data_plano">
                                <?php $__errorArgs = ['data_plano'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger text-xs pt-1"> <?php echo e($message); ?> </p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-6">
                            <label for="exampleFormControlSelect1">Status</label>
                            <select class="form-control" id="status_plano" name="status_plano">
                                <option value="em estudo">Em Andamento</option>
                                <option value="em planejado">Em Planejado</option>
                                <option value="Aguardando">Aguardando</option>
                                <?php $__errorArgs = ['status_plano'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger text-xs pt-1"> <?php echo e($message); ?> </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <label for="exampleFormControlSelect1">Vincular Edital</label>
                            <select class="form-control value=" <?php echo e(old('edital_plano')); ?>" name="edital_plano"
                                id="edital_plano">
                                <?php $__currentLoopData = $editals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($edital->id); ?>">
                                    <?php echo e($edital->instituicao_edital); ?>/<?php echo e($carbon::parse($edital->created_at)->format('y')); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['edital_plano'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger text-xs pt-1"> <?php echo e($message); ?> </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end mt-4">
                        <button type="button" name="button" class="btn btn-sm btn-light m-0">Cancel</button>
                        <button type="submit" name="button" class="btn btn-sm bg-gradient-primary m-0 ms-2">Criar
                            Plano</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\mystudy-prod\resources\views/pages/planoestudo/planoestudo-create.blade.php ENDPATH**/ ?>